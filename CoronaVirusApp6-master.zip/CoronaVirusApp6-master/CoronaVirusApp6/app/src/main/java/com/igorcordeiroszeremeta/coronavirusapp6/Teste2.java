package com.igorcordeiroszeremeta.coronavirusapp6;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class Teste2 extends AppCompatActivity {

    CheckBox doresEDesconfortos;
    CheckBox dorDeGarganta;
    CheckBox diarreia;
    Button botaoPaginaAnterior2;
    Button botaoProximo2;
    Button gravar2;
    TextView textoDoResultado2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);

      //  int resultado1 = parametros.getInt("resultado1");

        setContentView(R.layout.teste2);

        botaoProximo2 = findViewById(R.id.botaoProximo2);
        doresEDesconfortos = findViewById(R.id.doresEDesconfortos);
        dorDeGarganta = findViewById(R.id.dorDeGarganta);
        diarreia = findViewById(R.id.diarreia);
        botaoPaginaAnterior2= findViewById(R.id.botaoPaginaAnterior2);
        gravar2 = findViewById(R.id.gravar2);
        textoDoResultado2 = findViewById((R.id.textoDoResultado2));

        botaoProximo2.setOnClickListener(new View.OnClickListener() {

            public void onClick(View view) {
                    Intent intent = new Intent(getApplicationContext(), Teste2.class);
                    startActivity(intent);
            }
        });

        botaoPaginaAnterior2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(), Teste1.class);
                startActivity(intent);
            }
        });

        gravar2.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
             int resultado2 = 0;

                if (doresEDesconfortos.isChecked())
                    resultado2 += 4;

                if (dorDeGarganta.isChecked())
                    resultado2 += 4;

                if (diarreia.isChecked())
                    resultado2 += 4;

                Intent intentRecebedora = getIntent();
                Bundle bundleRecebedor = intentRecebedora.getExtras();
                int resultado1 = bundleRecebedor.getInt("resultado1");
                resultado2 += resultado1;
                textoDoResultado2.setText(String.valueOf(resultado2));
                Intent intentEnviadora = new Intent(getApplicationContext(), Teste3.class);
                Bundle bundleEnviador = new Bundle();
                bundleEnviador.putInt("resultado2", resultado2);
                intentEnviadora.putExtras(bundleEnviador);
                startActivity(intentEnviadora);
                Intent intent = new Intent(getApplicationContext(), Teste2.class);
                /*

                textoDoResultado2.setText(String.valueOf(resultadoDaSegundaPagina));
                Intent intentEnviadora = new Intent(getApplicationContext(), Teste3.class);
                Bundle parametro = new Bundle();

                parametro.putInt("resultado2", resultadoDaSegundaPagina);
                intentEnviadora.putExtras(parametro);
                startActivity(intentEnviadora);
                   */
                /*
                Intent intentRecebedora = getIntent();
                Bundle bundleRecebedor = intentRecebedora.getExtras();
                int resultado2 = bundleRecebedor.getInt("resultado1");
                resultado2 += resultado1;

                textoDoResultado2.setText(String.valueOf(resultado2));

                Intent intentEnviadora = new Intent(getApplicationContext(), Teste3.class);
                Bundle bundleEnviador = new Bundle();

                bundleEnviador.putInt("resultado2", resultado2);

                intentEnviadora.putExtras(bundleEnviador);

                startActivity(intentEnviadora);
                */

              //  Intent intent = new Intent(getApplicationContext(), Teste2.class);
            }
            });
    }
}

/*
                  resultado.setText(String.valueOf(resultadoDaPrimeiraPagina));
                  Intent intentEnviadora = new Intent(getApplicationContext(), Teste2.class);
                  Bundle parametro = new Bundle();

                parametro.putInt("resultado1", resultadoDaPrimeiraPagina);
                intentEnviadora.putExtras(parametro);
                startActivity(intentEnviadora);
 */